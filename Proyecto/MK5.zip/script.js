var swiper = new Swiper(".mySwiper", {

    slidePerView: 1,
    spacebewteen: 30,
    grabCursor: true,
    loop:true,
    breakpoints : {
        991: {
            slidesPerView:4
        }
    }

});